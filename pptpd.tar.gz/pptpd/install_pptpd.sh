#/bin/bash
#说明：操作系统请选择阿里云centos7.2，其他没试过，默认会自带ppp，全自动化一键安装pptpd服务
ip=`ifconfig | grep -A 1 eth0: | grep inet | awk -F' ' '{print $2}'`

rpm -ivh pptpd-1.4.0-2.el7.x86_64.rpm

echo "net.ipv4.ip_forward = 1" >> /etc/sysctl.conf
sysctl -p

echo "" > /etc/pptpd.conf
cat > /etc/pptpd.conf << EOF
option /etc/ppp/options.pptpd
logwtmp
EOF
echo "localip $ip" >> /etc/pptpd.conf
echo "remoteip 192.168.3.200-238" >> /etc/pptpd.conf

echo "" > /etc/ppp/options.pptpd
cat > /etc/ppp/options.pptpd << EOF
name pptpd
refuse-pap
refuse-chap
refuse-mschap
require-mschap-v2
require-mppe-128
ms-dns 8.8.8.8
ms-dns 114.114.114.114
proxyarp
lock
nobsdcomp
novj
novjccomp
nologfd
EOF

echo "" > /etc/ppp/chap-secrets
echo "appuser          pptpd     Admin123      *" > /etc/ppp/chap-secrets

sed -i 's/exit 0//' /etc/ppp/ip-up
echo 'ifconfig $1 mtu 1492' >> /etc/ppp/ip-up
echo "exit 0" >> /etc/ppp/ip-up

iptables -t nat -A POSTROUTING -s 192.168.3.0/24 -j MASQUERADE

systemctl start pptpd
systemctl enable pptpd

